# SecureGraphical

An improved text-based shoulder-surfing-resistant graphical password authentication system.

## Main specification

- Textual password length: 4–8 characters
- Project alphabet: `a b c d e f g h 1 2 3 4 5 6 7 8`
- 8 equally sized colour sectors
- 16 characters randomly distributed across the sectors
- Clockwise and anti-clockwise circular rotation
- One user-selected pass-colour
- Seven decoy-colours
- CAPTCHA verification
- Password hashing
- Failed-login lockout
- Account recovery
- Login history
- Security dashboard
- Responsive UI

## Run locally

### Windows

```bash
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open:

`http://127.0.0.1:5000`

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

## Important

The recovery page is intentionally demo-friendly: it verifies the stored recovery email and clears the temporary lock. For a production-grade system, replace this with a real email OTP or time-limited recovery token.

For Render, the included `render.yaml` uses Gunicorn and binds Flask to `0.0.0.0:$PORT`.

SQLite is suitable for a classroom/demo deployment. For production, use a managed database and persistent storage.
